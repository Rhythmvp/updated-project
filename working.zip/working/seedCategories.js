const mongoose = require('mongoose');

// MongoDB connection string (same as in server.js)
const MONGODB_URI = 'mongodb://localhost:27017/hr_software_hub';

// Category schema (same as in server.js)
const categorySchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true, trim: true },
    description: { type: String, trim: true }
}, { timestamps: true });

const Category = mongoose.model('Category', categorySchema);

// Sample HR software categories
const categories = [
    {
        name: 'Payroll',
        description: 'Software for managing employee salaries, taxes, and deductions.'
    },
    {
        name: 'Performance Management',
        description: 'Tools for tracking employee performance, goals, and reviews.'
    },
    {
        name: 'Attendance',
        description: 'Solutions for monitoring employee time, leave, and attendance.'
    },
    {
        name: 'Recruitment',
        description: 'Platforms for applicant tracking, job postings, and hiring processes.'
    },
    {
        name: 'Employee Engagement',
        description: 'Software to enhance employee satisfaction, surveys, and culture.'
    },
    {
        name: 'HRIS',
        description: 'Centralized systems for employee data management.'
    },
    {
        name: 'Learning Management',
        description: 'Systems for employee training, course delivery, and skill development.'
    }
];

// Function to seed categories
async function seedCategories() {
    try {
        // Connect to MongoDB
        await mongoose.connect(MONGODB_URI);
        console.log('Connected to MongoDB.');

        // Check for existing categories
        const existingCategories = await Category.find({}, 'name');
        const existingNames = existingCategories.map(cat => cat.name.toLowerCase());

        // Filter out categories that already exist
        const newCategories = categories.filter(
            cat => !existingNames.includes(cat.name.toLowerCase())
        );

        if (newCategories.length === 0) {
            console.log('No new categories to add. All categories already exist.');
            return;
        }

        // Insert new categories
        await Category.insertMany(newCategories);
        console.log(`Successfully added ${newCategories.length} categories:`);
        newCategories.forEach(cat => console.log(`- ${cat.name}`));

    } catch (error) {
        console.error('Error seeding categories:', error);
    } finally {
        // Close the connection
        await mongoose.connection.close();
        console.log('MongoDB connection closed.');
    }
}

// Run the seeding function
seedCategories();