const mongoose = require('mongoose');

const MONGODB_URI = 'mongodb://localhost:27017/hr_software_hub';

const softwareSchema = new mongoose.Schema({
    name: { type: String, required: true, trim: true },
    category: { type: String, required: true, trim: true },
    description: { type: String, required: true, trim: true },
    features: [{ type: String, trim: true }],
    pricing: [{
        plan: { type: String, required: true, trim: true },
        price: { type: String, required: true, trim: true }
    }],
    logo: { type: String, trim: true },
    screenshots: [{ type: String, trim: true }],
}, { timestamps: true });

const Software = mongoose.model('Software', softwareSchema);

const softwareData = [
    {
        name: 'Workday',
        category: 'HRIS',
        description: 'Comprehensive HRIS for employee data management and analytics.',
        features: ['Employee Records', 'Analytics', 'Self-Service Portal'],
        pricing: [
            { plan: 'Standard', price: '$15 per employee/month' },
            { plan: 'Enterprise', price: '$25 per employee/month' }
        ],
        logo: 'https://placehold.co/400x320?text=Workday',
        screenshots: ['https://placehold.co/400x320?text=Screenshot1']
    },
    {
        name: 'BambooHR',
        category: 'HRIS',
        description: 'User-friendly HRIS for small to medium businesses.',
        features: ['Applicant Tracking', 'Time-Off Management', 'Reporting'],
        pricing: [
            { plan: 'Essentials', price: '$6 per employee/month' },
            { plan: 'Advantage', price: '$10 per employee/month' }
        ],
        logo: 'https://placehold.co/400x320?text=BambooHR',
        screenshots: ['https://placehold.co/400x320?text=Screenshot2']
    },
    {
        name: 'Gusto',
        category: 'Payroll',
        description: 'Payroll and benefits management for small businesses.',
        features: ['Payroll Processing', 'Tax Filing', 'Benefits Administration'],
        pricing: [
            { plan: 'Simple', price: '$40/month + $6 per employee' },
            { plan: 'Plus', price: '$80/month + $12 per employee' }
        ],
        logo: 'https://placehold.co/400x320?text=Gusto',
        screenshots: ['https://placehold.co/400x320?text=Screenshot3']
    }
];

async function seedSoftware() {
    try {
        await mongoose.connect(MONGODB_URI);
        console.log('Connected to MongoDB.');

        const existingSoftware = await Software.find({}, 'name');
        const existingNames = existingSoftware.map(sw => sw.name.toLowerCase());

        const newSoftware = softwareData.filter(
            sw => !existingNames.includes(sw.name.toLowerCase())
        );

        if (newSoftware.length === 0) {
            console.log('No new software to add. All software already exist.');
            return;
        }

        await Software.insertMany(newSoftware);
        console.log(`Successfully added ${newSoftware.length} software:`);
        newSoftware.forEach(sw => console.log(`- ${sw.name}`));

    } catch (error) {
        console.error('Error seeding software:', error);
    } finally {
        await mongoose.connection.close();
        console.log('MongoDB connection closed.');
    }
}

seedSoftware();