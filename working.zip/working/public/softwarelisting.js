const API_BASE_URL = 'http://localhost:3000/api';

let allSoftwareData = [];

const modal = document.getElementById("software-detail-modal");
const closeBtn = document.querySelector(".close-btn");

const fetchAllSoftware = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/software`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}, URL: ${response.url}`);
        }
        allSoftwareData = await response.json();
        if (!Array.isArray(allSoftwareData)) {
            console.error("Fetched software data is not an array:", allSoftwareData);
            allSoftwareData = [];
        }
        renderSoftwareCards(allSoftwareData);
    } catch (error) {
        console.error("Error fetching software data:", error, "URL:", `${API_BASE_URL}/software`);
        const softwareGrid = document.getElementById("software-grid");
        if (softwareGrid) {
            softwareGrid.innerHTML = "<p>Could not load software listings. Please try again later.</p>";
        }
    }
};

const fetchCategories = async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/categories`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}, URL: ${response.url}`);
        }
        const categories = await response.json();
        if (!Array.isArray(categories)) {
            console.error("Fetched categories data is not an array:", categories);
            return [];
        }
        return categories;
    } catch (error) {
        console.error("Error fetching categories:", error, "URL:", `${API_BASE_URL}/categories`);
        return [];
    }
};

const renderCategoryButtons = async () => {
    const categoryFilter = document.querySelector(".category-filter");
    if (!categoryFilter) {
        console.error("Category filter container not found.");
        return;
    }

    const categories = await fetchCategories();
    categoryFilter.innerHTML = '<button class="category-btn active">All</button>';

    if (categories.length === 0) {
        categoryFilter.innerHTML += '<p>No categories available.</p>';
        return;
    }

    categories.forEach(category => {
        if (category && typeof category.name === 'string' && category.name.trim()) {
            const button = document.createElement('button');
            button.className = 'category-btn';
            button.textContent = category.name;
            categoryFilter.appendChild(button);
        }
    });

    // Attach event listeners to category buttons
    document.querySelectorAll(".category-btn").forEach(btn => {
        btn.addEventListener("click", function() {
            document.querySelectorAll(".category-btn").forEach(b => b.classList.remove("active"));
            this.classList.add("active");
            applyAllFilters();
        });
    });
};

function renderSoftwareCards(softwareList) {
    const softwareGrid = document.getElementById("software-grid");
    softwareGrid.innerHTML = "";

    if (!softwareList || softwareList.length === 0) {
        softwareGrid.innerHTML = "<p>No software listings found matching your criteria.</p>";
        return;
    }

    softwareList.forEach(software => {
        const card = createSoftwareCard(software);
        softwareGrid.appendChild(card);
    });
}

function createSoftwareCard(software) {
    const card = document.createElement("div");
    card.className = "software-card";
    card.setAttribute("data-id", software.id || software._id);

    const featuresHTML = Array.isArray(software.features) ?
        software.features.slice(0, 3).map(feature => `<div class="feature-item">${feature}</div>`).join('') :
        '';

    const logoUrl = software.logo || `${API_BASE_URL}/placeholder/400/320`;

    card.innerHTML = `
        <div class="card-img">
            <img src="${logoUrl}" alt="${software.name || 'Software'}">
        </div>
        <div class="card-content">
            <h3 class="card-title">${software.name || 'N/A'}</h3>
            <span class="card-category">${software.category || 'N/A'}</span>
            <div class="card-features">
                ${featuresHTML}
            </div>
            <div class="card-footer">
                <a href="#" class="btn btn-demo">Request Demo</a>
                <a href="#" class="btn btn-price">Get Price</a>
            </div>
        </div>
    `;

    card.addEventListener("click", async function(e) {
        if (e.target.closest('.btn')) {
            return;
        }
        const softwareId = this.getAttribute('data-id');
        const fullSoftwareDetails = allSoftwareData.find(s => (s.id || s._id).toString() === softwareId);
        if (fullSoftwareDetails) {
            populateModal(fullSoftwareDetails);
            modal.style.display = "block";
            document.body.style.overflow = "hidden";
        } else {
            console.error("Could not find details for software ID:", softwareId);
        }
    });
    return card;
}

if (closeBtn) {
    closeBtn.addEventListener("click", function() {
        modal.style.display = "none";
        document.body.style.overflow = "auto";
    });
}

if (modal) {
    window.addEventListener("click", function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
            document.body.style.overflow = "auto";
        }
    });
}

function populateModal(software) {
    const detailLogo = document.querySelector(".detail-logo img");
    const detailTitle = document.querySelector(".detail-title h2");
    const detailCategory = document.querySelector(".detail-category");
    const detailDescription = document.querySelector(".detail-description p");
    const featureList = document.querySelector(".feature-list");
    const screenshotsContainer = document.querySelector(".detail-main .screenshots");
    const pricingTableBody = document.querySelector(".pricing-table table tbody");

    if (!detailLogo || !detailTitle || !detailCategory || !detailDescription || !featureList || !screenshotsContainer || !pricingTableBody) {
        console.error("One or more modal elements not found!");
        return;
    }
    
    detailLogo.src = software.logo || `${API_BASE_URL}/placeholder/400/320`;
    detailLogo.alt = software.name || 'Software Logo';
    detailTitle.textContent = software.name || 'N/A';
    detailCategory.textContent = software.category || 'N/A';
    detailDescription.textContent = software.description || 'No description available.';

    featureList.innerHTML = "";
    if (Array.isArray(software.features)) {
        software.features.forEach(feature => {
            featureList.innerHTML += `<li>${feature}</li>`;
        });
    }

    screenshotsContainer.innerHTML = "";
    if (Array.isArray(software.screenshots)) {
        software.screenshots.forEach(screenshotUrl => {
            screenshotsContainer.innerHTML += `
                <div class="screenshot">
                    <img src="${screenshotUrl}" alt="${software.name || 'Screenshot'} Screenshot">
                </div>
            `;
        });
    }
    if (screenshotsContainer.innerHTML === "") {
         screenshotsContainer.innerHTML = "<p>No screenshots available.</p>";
    }

    pricingTableBody.innerHTML = "";
    if (Array.isArray(software.pricing) && software.pricing.length > 0) {
        software.pricing.forEach(price => {
            pricingTableBody.innerHTML += `
                <tr>
                    <td>${price.plan || 'N/A'}</td>
                    <td>${price.price || 'N/A'}</td>
                </tr>
            `;
        });
    } else {
        pricingTableBody.innerHTML = '<tr><td colspan="2">Pricing information not available.</td></tr>';
    }
}

const searchInput = document.querySelector(".search-bar input");
const searchButton = document.querySelector(".search-bar button");

if (searchButton) {
    searchButton.addEventListener("click", applyAllFilters);
}
if (searchInput) {
    searchInput.addEventListener("keyup", function(event) {
        if (event.key === "Enter") {
            applyAllFilters();
        }
    });
}

const companyFilter = document.getElementById("company-filter");
const pricingFilter = document.getElementById("pricing-filter");
const featuresFilter = document.getElementById("features-filter");

[companyFilter, pricingFilter, featuresFilter].forEach(filter => {
    if (filter) filter.addEventListener("change", applyAllFilters);
});

function applyAllFilters() {
    let filteredSoftware = [...allSoftwareData];

    const activeCategoryBtn = document.querySelector(".category-btn.active");
    const selectedCategory = activeCategoryBtn ? activeCategoryBtn.textContent : "All";
    if (selectedCategory !== "All") {
        filteredSoftware = filteredSoftware.filter(software => software.category === selectedCategory);
    }

    const query = searchInput ? searchInput.value.toLowerCase().trim() : "";
    if (query) {
        filteredSoftware = filteredSoftware.filter(software => {
            const name = (software.name || "").toLowerCase();
            const category = (software.category || "").toLowerCase();
            const features = Array.isArray(software.features) ? software.features.map(f => (f || "").toLowerCase()) : [];
            const description = (software.description || "").toLowerCase();
            return name.includes(query) ||
                   category.includes(query) ||
                   features.some(feature => feature.includes(query)) ||
                   description.includes(query);
        });
    }
    
    const selectedCompany = companyFilter ? companyFilter.value.toLowerCase() : "";
    if (selectedCompany) {
        filteredSoftware = filteredSoftware.filter(software => (software.name || "").toLowerCase().includes(selectedCompany));
    }

    const selectedFeatureKeyword = featuresFilter ? featuresFilter.value.toLowerCase() : "";
    if (selectedFeatureKeyword) {
        filteredSoftware = filteredSoftware.filter(software => 
            Array.isArray(software.features) && software.features.some(feature => (feature || "").toLowerCase().includes(selectedFeatureKeyword))
        );
    }

    const selectedPricingRange = pricingFilter ? pricingFilter.value : "";
    if (selectedPricingRange) {
        filteredSoftware = filteredSoftware.filter(software => {
            if (!Array.isArray(software.pricing) || software.pricing.length === 0) return false;
            return software.pricing.some(p => {
                const priceText = (p.price || "").toLowerCase();
                switch(selectedPricingRange) {
                    case 'free': return priceText.includes('free');
                    case 'low': {
                        const match = priceText.match(/[\d\.]+/);
                        if (match) return parseFloat(match[0]) <= 10;
                        return false;
                    }
                    default: return true;
                }
            });
        });
    }

    renderSoftwareCards(filteredSoftware);
}

async function initializePublicPage() {
    await Promise.all([
        fetchAllSoftware(),
        renderCategoryButtons()
    ]);
}

document.addEventListener('DOMContentLoaded', initializePublicPage);