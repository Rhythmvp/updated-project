const API_BASE_URL = 'http://localhost:3000/api';

const loadData = async (endpoint) => {
    try {
        const url = `${API_BASE_URL}/${endpoint}`;
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}, URL: ${url}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`Error loading ${endpoint}:`, error, "URL:", `${API_BASE_URL}/${endpoint}`);
        showErrorMessage(`Failed to load ${endpoint}.`);
        return [];
    }
};

const saveData = async (endpoint, data, method = 'POST', id = null) => {
    try {
        const url = id ? `${API_BASE_URL}/${endpoint}/${id}` : `${API_BASE_URL}/${endpoint}`;
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP error! status: ${response.status}, URL: ${url}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`Error saving ${endpoint}:`, error, "URL:", url);
        showErrorMessage(error.message || `Failed to save ${endpoint}.`);
        return null;
    }
};

const addSoftware = async (formData) => {
    const result = await saveData('software', formData, 'POST');
    if (result) {
        await populateSoftwareTable();
        await populateCategoriesTable();
        showSuccessMessage('Software added successfully!');
        return result;
    }
};

const updateSoftware = async (id, formData) => {
    const result = await saveData('software', formData, 'PUT', id);
    if (result) {
        await populateSoftwareTable();
        await populateCategoriesTable();
        showSuccessMessage('Software updated successfully!');
        return result;
    }
};

const deleteSoftware = async (id) => {
    const result = await saveData('software', {}, 'DELETE', id);
    if (result) {
        await populateSoftwareTable();
        await populateCategoriesTable();
        showSuccessMessage('Software deleted successfully!');
        return result;
    }
};

const populateSoftwareTable = async () => {
    const softwareList = await loadData('software');
    const tableBody = document.getElementById('software-table-body');
    tableBody.innerHTML = '';

    if (!softwareList || softwareList.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="5">No software listings found.</td></tr>';
        return;
    }

    softwareList.forEach(sw => {
        const row = document.createElement('tr');
        const featuresText = Array.isArray(sw.features) ? sw.features.join(', ') : '';
        row.innerHTML = `
            <td>${sw.id || sw._id}</td>
            <td>${sw.name}</td>
            <td><span class="category-badge">${sw.category}</span></td>
            <td>${featuresText}</td>
            <td class="actions-cell">
                <button class="btn-action btn-view" data-id="${sw.id || sw._id}">View</button>
                <button class="btn-action btn-edit" data-id="${sw.id || sw._id}">Edit</button>
                <button class="btn-action btn-delete" data-id="${sw.id || sw._id}">Delete</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
    attachEventListeners();
};

const addCategory = async (formData) => {
    const result = await saveData('categories', formData, 'POST');
    if (result) {
        await populateCategoriesTable();
        await populateCategoryDropdown();
        showSuccessMessage('Category added successfully!');
        return result;
    }
};

const updateCategory = async (id, formData) => {
    const result = await saveData('categories', formData, 'PUT', id);
    if (result) {
        await populateSoftwareTable();
        await populateCategoriesTable();
        await populateCategoryDropdown();
        showSuccessMessage('Category updated successfully!');
        return result;
    }
};

const deleteCategory = async (id) => {
    const result = await saveData('categories', {}, 'DELETE', id);
    if (result) {
        await populateCategoriesTable();
        await populateCategoryDropdown();
        showSuccessMessage('Category deleted successfully!');
        return result;
    }
};

const populateCategoriesTable = async () => {
    const categories = await loadData('categories');
    const tableBody = document.getElementById('categories-table-body');
    tableBody.innerHTML = '';

    if (!categories || categories.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="4">No categories found.</td></tr>';
        return;
    }

    categories.forEach(category => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${category.id || category._id}</td>
            <td>${category.name}</td>
            <td>${category.softwareCount || 0}</td>
            <td class="actions-cell">
                <button class="btn-action btn-edit-category" data-id="${category.id || category._id}">Edit</button>
                <button class="btn-action btn-delete-category" data-id="${category.id || category._id}">Delete</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
    attachCategoryEventListeners();
};

const populateCategoryDropdown = async () => {
    const dropdown = document.getElementById('software-category');
    if (!dropdown) {
        console.error('Dropdown element #software-category not found.');
        return;
    }

    dropdown.disabled = true;
    const originalPlaceholder = dropdown.options[0].textContent;
    dropdown.options[0].textContent = 'Loading categories...';

    try {
        const categories = await loadData('categories');
        
        while (dropdown.options.length > 1) {
            dropdown.remove(1);
        }

        if (!categories || categories.length === 0) {
            dropdown.options[0].textContent = 'No categories available';
            return;
        }

        categories.forEach(category => {
            if (category && typeof category.name === 'string' && category.name.trim()) {
                const option = document.createElement('option');
                option.value = category.name;
                option.textContent = category.name;
                dropdown.appendChild(option);
            } else {
                console.warn('Invalid category data:', category);
            }
        });

        dropdown.options[0].textContent = originalPlaceholder;
    } catch (error) {
        console.error('Failed to populate category dropdown:', error);
        dropdown.options[0].textContent = 'Error loading categories';
    } finally {
        dropdown.disabled = false;
    }
};

const loadSettings = async () => {
    const settings = await loadData('settings');
    if (settings) {
        document.getElementById('site-title').value = settings.siteTitle || 'HR Software Hub';
        document.getElementById('site-description').value = settings.siteDescription || '';
        document.getElementById('contact-email').value = settings.contactEmail || '';
        document.getElementById('items-per-page').value = settings.itemsPerPage || 12;
    }
};

const updateSettings = async (formData) => {
    const result = await saveData('settings', formData, 'PUT');
    if (result) {
        showSuccessMessage('Settings updated successfully!');
    }
};

const showSuccessMessage = (messageText = 'Operation completed successfully!') => {
    const messageElement = document.getElementById('success-message');
    messageElement.textContent = messageText;
    messageElement.style.display = 'block';
    setTimeout(() => {
        messageElement.style.display = 'none';
    }, 3000);
};

const showErrorMessage = (message) => {
    const messageElement = document.getElementById('error-message');
    messageElement.textContent = message || 'An error occurred. Please try again.';
    messageElement.style.display = 'block';
    setTimeout(() => {
        messageElement.style.display = 'none';
    }, 3000);
};

const getSoftwareFormData = () => {
    const name = document.getElementById('software-name').value;
    const category = document.getElementById('software-category').value;
    const description = document.getElementById('software-description').value;
    const logo = document.getElementById('software-logo').value;
    const features = [];
    document.querySelectorAll('#features-container .feature-input').forEach(input => {
        if (input.value.trim() !== '') {
            features.push(input.value.trim());
        }
    });
    const pricing = [];
    document.querySelectorAll('#pricing-container .pricing-row').forEach(row => {
        const plan = row.querySelector('.pricing-plan').value.trim();
        const price = row.querySelector('.pricing-price').value.trim();
        if (plan !== '' && price !== '') {
            pricing.push({ plan, price });
        }
    });
    const screenshots = [];
    document.querySelectorAll('#screenshots-container .screenshot-item img').forEach(img => {
        screenshots.push(img.src);
    });
    return { name, category, description, features, pricing, logo, screenshots };
};

const getCategoryFormData = () => {
    const name = document.getElementById('category-name').value;
    const description = document.getElementById('category-description').value;
    return { name, description };
};

const getSettingsFormData = () => {
    return {
        siteTitle: document.getElementById('site-title').value,
        siteDescription: document.getElementById('site-description').value,
        contactEmail: document.getElementById('contact-email').value,
        itemsPerPage: parseInt(document.getElementById('items-per-page').value)
    };
};

const populateSoftwareForm = (software) => {
    document.getElementById('software-id').value = software.id || software._id;
    document.getElementById('software-name').value = software.name;
    document.getElementById('software-category').value = software.category;
    document.getElementById('software-description').value = software.description;
    document.getElementById('software-logo').value = software.logo;
    
    const featuresContainer = document.getElementById('features-container');
    featuresContainer.innerHTML = '';
    if (Array.isArray(software.features)) {
        software.features.forEach(feature => addFeatureRow(feature));
    }
    
    const pricingContainer = document.getElementById('pricing-container');
    pricingContainer.innerHTML = '';
    if (Array.isArray(software.pricing)) {
        software.pricing.forEach(p => addPricingRow(p.plan, p.price));
    }
    
    const screenshotsContainer = document.getElementById('screenshots-container');
    screenshotsContainer.innerHTML = '';
    if (Array.isArray(software.screenshots)) {
        software.screenshots.forEach(screenshot => addScreenshotItem(screenshot));
    }
    updatePreview();
};

const handleEditSoftware = async (id) => {
    const software = await loadData(`software/${id}`);
    if (software) {
        document.querySelector('#software-form .form-title').textContent = 'Edit Software';
        populateSoftwareForm(software);
        document.getElementById('software-form').classList.add('active');
    } else {
        showErrorMessage('Software not found.');
    }
};

const handleViewSoftware = async (id) => {
    const software = await loadData(`software/${id}`);
    if (software) {
        alert(`Software Details:\n\nName: ${software.name}\nCategory: ${software.category}\nDescription: ${software.description}\nFeatures: ${Array.isArray(software.features) ? software.features.join(', ') : ''}`);
    }
};

const handleDeleteSoftware = (id) => {
    if (confirm('Are you sure you want to delete this software?')) {
        deleteSoftware(id);
    }
};

const handleEditCategory = async (id) => {
    const category = await loadData(`categories/${id}`);
    if (category) {
        document.querySelector('#category-form .form-title').textContent = 'Edit Category';
        document.getElementById('category-id').value = category.id || category._id;
        document.getElementById('category-name').value = category.name;
        document.getElementById('category-description').value = category.description || '';
        document.getElementById('category-form').classList.add('active');
    } else {
        showErrorMessage('Category not found.');
    }
};

const handleDeleteCategory = (id) => {
    if (confirm('Are you sure you want to delete this category? This might fail if software listings are using it.')) {
        deleteCategory(id);
    }
};

const addFeatureRow = (value = '') => {
    const featureRow = document.createElement('div');
    featureRow.className = 'feature-row';
    featureRow.innerHTML = `
        <input type="text" class="form-control feature-input" placeholder="Enter a feature" value="${value}">
        <button type="button" class="btn-remove-feature">×</button>
    `;
    document.getElementById('features-container').appendChild(featureRow);
    featureRow.querySelector('.btn-remove-feature').addEventListener('click', function() {
        featureRow.remove();
        updatePreview();
    });
    return featureRow;
};

const addPricingRow = (plan = '', price = '') => {
    const pricingRow = document.createElement('div');
    pricingRow.className = 'pricing-row';
    pricingRow.innerHTML = `
        <input type="text" class="form-control pricing-plan" placeholder="Plan Name" value="${plan}">
        <input type="text" class="form-control pricing-price" placeholder="Price" value="${price}">
        <button type="button" class="btn-remove-pricing">×</button>
    `;
    document.getElementById('pricing-container').appendChild(pricingRow);
    pricingRow.querySelector('.btn-remove-pricing').addEventListener('click', function() {
        pricingRow.remove();
    });
    return pricingRow;
};

const addScreenshotItem = (src = `${API_BASE_URL}/placeholder/400/320`) => {
    const screenshotItem = document.createElement('div');
    screenshotItem.className = 'screenshot-item';
    screenshotItem.innerHTML = `
        <img src="${src}" alt="Screenshot">
        <button type="button" class="btn-remove-screenshot">×</button>
    `;
    document.getElementById('screenshots-container').appendChild(screenshotItem);
    screenshotItem.querySelector('.btn-remove-screenshot').addEventListener('click', function() {
        screenshotItem.remove();
    });
    return screenshotItem;
};

const updatePreview = () => {
    const softwareName = document.getElementById('software-name').value || 'Software Name';
    const category = document.getElementById('software-category').value || 'Category';
    let logoUrl = document.getElementById('software-logo').value;
    if (!logoUrl) {
        logoUrl = `${API_BASE_URL}/placeholder/400/320`;
    }
    document.getElementById('preview-title').textContent = softwareName;
    document.getElementById('preview-category').textContent = category;
    document.getElementById('preview-image').src = logoUrl;
    const previewFeatures = document.getElementById('preview-features');
    previewFeatures.innerHTML = '';
    document.querySelectorAll('.feature-input').forEach(input => {
        if (input.value.trim() !== '') {
            const featureItem = document.createElement('div');
            featureItem.className = 'preview-feature-item';
            featureItem.textContent = input.value;
            previewFeatures.appendChild(featureItem);
        }
    });
};

const attachEventListeners = () => {
    document.querySelectorAll('.btn-view').forEach(btn => {
        btn.addEventListener('click', function() {
            handleViewSoftware(this.getAttribute('data-id'));
        });
    });
    document.querySelectorAll('.btn-edit').forEach(btn => {
        btn.addEventListener('click', function() {
            handleEditSoftware(this.getAttribute('data-id'));
        });
    });
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', function() {
            handleDeleteSoftware(this.getAttribute('data-id'));
        });
    });
};

const attachCategoryEventListeners = () => {
    document.querySelectorAll('.btn-edit-category').forEach(btn => {
        btn.addEventListener('click', function() {
            handleEditCategory(this.getAttribute('data-id'));
        });
    });
    document.querySelectorAll('.btn-delete-category').forEach(btn => {
        btn.addEventListener('click', function() {
            handleDeleteCategory(this.getAttribute('data-id'));
        });
    });
};

const initializeAdmin = async () => {
    await populateSoftwareTable();
    await populateCategoriesTable();
    await populateCategoryDropdown();
    await loadSettings();

    document.querySelectorAll('.sidebar-menu a').forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelectorAll('.sidebar-menu a').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            this.classList.add('active');
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId)?.classList.add('active');
        });
    });

    document.getElementById('add-software-btn').addEventListener('click', function() {
        document.getElementById('software-form-element').reset();
        document.querySelector('#software-form .form-title').textContent = 'Add New Software';
        document.getElementById('software-id').value = '';
        document.getElementById('features-container').innerHTML = '';
        document.getElementById('pricing-container').innerHTML = '';
        document.getElementById('screenshots-container').innerHTML = '';
        addFeatureRow();
        addPricingRow();
        document.getElementById('software-form').classList.add('active');
        updatePreview();
    });

    document.getElementById('cancel-form-btn').addEventListener('click', function() {
        document.getElementById('software-form').classList.remove('active');
    });

    document.getElementById('add-feature-btn').addEventListener('click', function() { addFeatureRow(); updatePreview(); });
    document.getElementById('add-pricing-btn').addEventListener('click', addPricingRow);
    document.getElementById('add-screenshot-btn').addEventListener('click', () => addScreenshotItem());

    document.getElementById('add-category-btn').addEventListener('click', function() {
        document.getElementById('category-form-element').reset();
        document.querySelector('#category-form .form-title').textContent = 'Add New Category';
        document.getElementById('category-id').value = '';
        document.getElementById('category-form').classList.add('active');
    });

    document.getElementById('cancel-category-form-btn').addEventListener('click', function() {
        document.getElementById('category-form').classList.remove('active');
    });

    document.getElementById('software-form-element').addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = getSoftwareFormData();
        const softwareId = document.getElementById('software-id').value;
        if (softwareId) {
            await updateSoftware(softwareId, formData);
        } else {
            await addSoftware(formData);
        }
        document.getElementById('software-form').classList.remove('active');
    });

    document.getElementById('category-form-element').addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = getCategoryFormData();
        const categoryId = document.getElementById('category-id').value;
        if (categoryId) {
            await updateCategory(categoryId, formData);
        } else {
            await addCategory(formData);
        }
        document.getElementById('category-form').classList.remove('active');
    });

    document.getElementById('settings-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = getSettingsFormData();
        await updateSettings(formData);
    });

    document.getElementById('software-name').addEventListener('input', updatePreview);
    document.getElementById('software-category').addEventListener('change', updatePreview);
    document.getElementById('software-logo').addEventListener('input', updatePreview);
};

document.addEventListener('DOMContentLoaded', initializeAdmin);