const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const PORT = process.env.PORT || 3000;
const MONGODB_URI = "mongodb://localhost:27017/hr_software_hub";

const app = express();

app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    console.log('Headers:', req.headers);
    console.log('Query:', req.query);
    console.log('Body:', req.body);
    next();
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

mongoose.connect(MONGODB_URI)
    .then(() => console.log('Successfully connected to MongoDB.'))
    .catch(err => {
        console.error('MongoDB connection error:', err);
        process.exit(1);
    });

const pricingPlanSchema = new mongoose.Schema({
    plan: { type: String, required: true, trim: true },
    price: { type: String, required: true, trim: true }
}, { _id: false });

const softwareSchema = new mongoose.Schema({
    name: { type: String, required: [true, "Software name is required"], trim: true },
    category: { type: String, required: [true, "Category is required"], trim: true },
    description: { type: String, required: [true, "Description is required"], trim: true },
    features: [{ type: String, trim: true }],
    pricing: [pricingPlanSchema],
    logo: { type: String, trim: true, default: '/api/placeholder/400/320' },
    screenshots: [{ type: String, trim: true }],
}, { timestamps: true });

const Software = mongoose.model('Software', softwareSchema);

const categorySchema = new mongoose.Schema({
    name: { type: String, required: [true, "Category name is required"], unique: true, trim: true },
    description: { type: String, trim: true }
}, { timestamps: true });

const Category = mongoose.model('Category', categorySchema);

const settingsSchema = new mongoose.Schema({
    fixedId: { type: String, default: "main_settings", unique: true },
    siteTitle: { type: String, default: 'HR Software Hub' },
    siteDescription: { type: String, default: 'Find the best HR software solutions for your business needs.' },
    contactEmail: { type: String, default: 'contact@example.com' },
    itemsPerPage: { type: Number, default: 12 }
}, { timestamps: true });

const Settings = mongoose.model('Settings', settingsSchema);

const handleError = (res, error, message = "Server Error", statusCode = 500) => {
    console.error(message, error);
    res.status(statusCode).json({ message, error: error.message || error });
};

app.get('/api/software', async (req, res) => {
    try {
        const softwareList = await Software.find().sort({ createdAt: -1 });
        res.json(softwareList);
    } catch (error) {
        handleError(res, error, "Error fetching software list.");
    }
});

app.post('/api/software', async (req, res) => {
    try {
        const newSoftware = new Software(req.body);
        await newSoftware.save();
        res.status(201).json(newSoftware);
    } catch (error) {
        if (error.name === 'ValidationError') {
            handleError(res, error, "Validation Error", 400);
        } else {
            handleError(res, error, "Error adding new software.");
        }
    }
});

app.get('/api/software/:id', async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ message: "Invalid software ID format." });
        }
        const software = await Software.findById(req.params.id);
        if (!software) {
            return res.status(404).json({ message: "Software not found." });
        }
        res.json(software);
    } catch (error) {
        handleError(res, error, "Error fetching software details.");
    }
});

app.put('/api/software/:id', async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ message: "Invalid software ID format." });
        }
        const updatedSoftware = await Software.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!updatedSoftware) {
            return res.status(404).json({ message: "Software not found to update." });
        }
        res.json(updatedSoftware);
    } catch (error) {
        if (error.name === 'ValidationError') {
            handleError(res, error, "Validation Error", 400);
        } else {
            handleError(res, error, "Error updating software.");
        }
    }
});

app.delete('/api/software/:id', async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ message: "Invalid software ID format." });
        }
        const deletedSoftware = await Software.findByIdAndDelete(req.params.id);
        if (!deletedSoftware) {
            return res.status(404).json({ message: "Software not found to delete." });
        }
        res.json({ message: "Software deleted successfully.", id: req.params.id });
    } catch (error) {
        handleError(res, error, "Error deleting software.");
    }
});

app.get('/api/categories', async (req, res) => {
    try {
        const categories = await Category.find().sort({ name: 1 });
        const categoriesWithCounts = await Promise.all(
            categories.map(async (category) => {
                const count = await Software.countDocuments({ category: category.name });
                return {
                    _id: category._id,
                    id: category._id,
                    name: category.name,
                    description: category.description,
                    softwareCount: count,
                    createdAt: category.createdAt,
                    updatedAt: category.updatedAt
                };
            })
        );
        res.json(categoriesWithCounts);
    } catch (error) {
        handleError(res, error, "Error fetching categories.");
    }
});

app.post('/api/categories', async (req, res) => {
    try {
        const existingCategory = await Category.findOne({ name: { $regex: new RegExp(`^${req.body.name}$`, 'i') } });
        if (existingCategory) {
            return res.status(400).json({ message: `Category '${req.body.name}' already exists.` });
        }
        const newCategory = new Category(req.body);
        await newCategory.save();
        res.status(201).json({ ...newCategory.toObject(), softwareCount: 0 });
    } catch (error) {
        if (error.name === 'ValidationError') {
            handleError(res, error, "Validation Error", 400);
        } else {
            handleError(res, error, "Error adding new category.");
        }
    }
});

app.get('/api/categories/:id', async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ message: "Invalid category ID format." });
        }
        const category = await Category.findById(req.params.id);
        if (!category) {
            return res.status(404).json({ message: "Category not found." });
        }
        const count = await Software.countDocuments({ category: category.name });
        res.json({ ...category.toObject(), softwareCount: count });
    } catch (error) {
        handleError(res, error, "Error fetching category details.");
    }
});

app.put('/api/categories/:id', async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ message: "Invalid category ID format." });
        }
        const categoryToUpdate = await Category.findById(req.params.id);
        if (!categoryToUpdate) {
            return res.status(404).json({ message: "Category not found to update." });
        }
        const oldCategoryName = categoryToUpdate.name;
        const newCategoryName = req.body.name;
        if (newCategoryName && newCategoryName.toLowerCase() !== oldCategoryName.toLowerCase()) {
            const existingCategory = await Category.findOne({
                name: { $regex: new RegExp(`^${newCategoryName}$`, 'i') },
                _id: { $ne: req.params.id }
            });
            if (existingCategory) {
                return res.status(400).json({ message: `Category name '${newCategoryName}' already exists.` });
            }
        }
        const updatedCategory = await Category.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (newCategoryName && oldCategoryName !== newCategoryName) {
            await Software.updateMany({ category: oldCategoryName }, { $set: { category: newCategoryName } });
        }
        const count = await Software.countDocuments({ category: updatedCategory.name });
        res.json({ ...updatedCategory.toObject(), softwareCount: count });
    } catch (error) {
        if (error.name === 'ValidationError') {
            handleError(res, error, "Validation Error", 400);
        } else {
            handleError(res, error, "Error updating category.");
        }
    }
});

app.delete('/api/categories/:id', async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ message: "Invalid category ID format." });
        }
        const category = await Category.findById(req.params.id);
        if (!category) {
            return res.status(404).json({ message: "Category not found to delete." });
        }
        const softwareUsingCategory = await Software.countDocuments({ category: category.name });
        if (softwareUsingCategory > 0) {
            return res.status(400).json({ message: `Cannot delete category '${category.name}' as it is currently assigned to ${softwareUsingCategory} software listing(s). Please reassign them first.` });
        }
        await Category.findByIdAndDelete(req.params.id);
        res.json({ message: "Category deleted successfully.", id: req.params.id });
    } catch (error) {
        handleError(res, error, "Error deleting category.");
    }
});

app.get('/api/settings', async (req, res) => {
    try {
        let settings = await Settings.findOne({ fixedId: "main_settings" });
        if (!settings) {
            settings = new Settings();
            await settings.save();
        }
        res.json(settings);
    } catch (error) {
        handleError(res, error, "Error fetching settings.");
    }
});

app.put('/api/settings', async (req, res) => {
    try {
        const updatedSettings = await Settings.findOneAndUpdate(
            { fixedId: "main_settings" },
            req.body,
            { new: true, upsert: true, runValidators: true }
        );
        res.json(updatedSettings);
    } catch (error) {
        if (error.name === 'ValidationError') {
            handleError(res, error, "Validation Error", 400);
        } else {
            handleError(res, error, "Error updating settings.");
        }
    }
});

app.get('/api/placeholder/:width/:height', (req, res) => {
    const { width, height } = req.params;
    if (!/^\d+$/.test(width) || !/^\d+$/.test(height)) {
        return res.status(400).json({ message: 'Width and height must be positive integers.' });
    }
    res.redirect(`https://placehold.co/${width}x${height}/00573F/FFFFFF?text=HR+Hub`);
});

app.use(express.static(path.join(__dirname, 'public')));

app.get('/admin', (req, res, next) => {
    if (!req.path.startsWith('/api/')) {
        if (req.path.includes('://') || req.path.includes('git.new')) {
            console.warn(`Invalid request path detected: ${req.path}`);
            return res.status(400).json({ message: 'Invalid request path.' });
        }
        res.sendFile(path.join(__dirname, 'public', 'admin.html'));
    } else {
        next();
    }
});

app.get('/software', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'softwarelistings.html'));
});

app.use('/api/*', (req, res) => {
    res.status(404).json({ message: 'API endpoint not found.' });
});

app.use((err, req, res, next) => {
    console.error("Unhandled error:", err.stack);
    res.status(500).send({ message: 'Something broke on the server!', error: err.message });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});